from datetime import datetime
from typing import List, Optional

from pydantic import BaseModel, Field


class CreateApiTokenRequestDto(BaseModel):
    name: str
    expires_in_days: int = Field(serialization_alias="expiresInDays")
    scopes: List[str] = Field(default_factory=lambda: ["*"])


class ApiTokenDto(BaseModel):
    uuid: str
    name: str
    expire_at: datetime = Field(..., alias="expireAt")
    scopes: List[str]
    created_at: datetime = Field(..., alias="createdAt")
    updated_at: datetime = Field(..., alias="updatedAt")


class CreateApiTokenResponseDto(ApiTokenDto):
    token: str


class DeleteApiTokenResponseDto(BaseModel):
    response: bool


class DocsInfoDto(BaseModel):
    enabled: bool
    scalar_path: Optional[str] = Field(None, alias="scalarPath")
    swagger_path: Optional[str] = Field(None, alias="swaggerPath")


class FindAllApiTokensResponseData(BaseModel):
    tokens: List[ApiTokenDto]
    docs: DocsInfoDto


class FindAllApiTokensResponseDto(FindAllApiTokensResponseData):
    pass


class ApiTokenScopeEndpointDto(BaseModel):
    key: str
    kind: str
    method: str
    path: str
    description: str


class ApiTokenScopeResourceDto(BaseModel):
    resource: str
    resource_scopes: List[str] = Field(..., alias="resourceScopes")
    endpoints: List[ApiTokenScopeEndpointDto]


class GetApiTokenScopesResponseData(BaseModel):
    wildcard: str
    resources: List[ApiTokenScopeResourceDto]


class GetApiTokenScopesResponseDto(GetApiTokenScopesResponseData):
    pass
